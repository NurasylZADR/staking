export const nftDropContractAddress =
  "0x86eAf8D635eb11D5CD801c41744F44e50d4fd8d2";
export const tokenContractAddress =
  "0x12ea05ba6E8405cBeceB5b51134A821e86858F7E";
export const stakingContractAddress =
  "0x830Ace54DFbf3a011601bD0Bc1f9806d45D2d0E4";
